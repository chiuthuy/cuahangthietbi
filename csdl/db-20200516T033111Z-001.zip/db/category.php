<?php
include "connect.php";

$query = "SELECT * FROM loaisanpham";
$data = mysqli_query($conn, $query);
$mangloaisp = array();

while ($row = mysqli_fetch_assoc($data)) {
	array_push($mangloaisp, new Category(
		$row['id'],
		$row['tenloaisanpham'],
		$row['hinhanhloaisanpham']
	));
}

echo json_encode($mangloaisp);

class Category
{
	function Category($id, $tenloaisp, $hinhanhloaisp)
	{
		$this->id = $id;
		$this->tenloaisp = $tenloaisp;
		$this->hinhanhloaisp = $hinhanhloaisp;
	}
}
